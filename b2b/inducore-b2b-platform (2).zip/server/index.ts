import express from 'express';
import cors from 'cors';
import { Pool } from 'pg';
import multer from 'multer';
import ExcelJS from 'exceljs';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.API_PORT || 3001;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(cors());
app.use(express.json());
// Serve uploaded files statically
app.use('/uploads', express.static(path.join(__dirname, '../public/uploads')));

// --- Helper: Get Product Data for Export ---
async function getFullProductDataForExport() {
    const res = await pool.query(`
        SELECT 
            p.id, p.model_name, p.summary, p.description, 
            c.etim_code, 
            (SELECT file_url FROM media_assets WHERE bind_to_id = p.id AND type='image' ORDER BY sort_order LIMIT 1) as main_image
        FROM products p
        LEFT JOIN categories c ON p.primary_category_id = c.id
    `);
    return res.rows;
}

// --- API: Public Product Data ---
app.get('/api/products', async (req, res) => {
    const { lang = 'en', category } = req.query;
    // Simple logic: fetch all and let frontend filter or basic SQL filter
    const query = `
        SELECT p.id, p.model_name, p.slug_i18n->>$1 as slug, p.summary->>$1 as summary, 
               (SELECT file_url FROM media_assets WHERE bind_to_id = p.id AND type='image' LIMIT 1) as thumb
        FROM products p
    `;
    const { rows } = await pool.query(query, [lang]);
    res.json(rows);
});

// --- API: Documents ---
app.get('/api/documents', async (req, res) => {
    // Return all public documents
    try {
        const { rows } = await pool.query(`
            SELECT * FROM documents 
            WHERE access_level = 'public' 
            ORDER BY doc_type, publish_date DESC
        `);
        res.json(rows);
    } catch (e) {
        console.error(e);
        res.status(500).json({ error: 'Database error' });
    }
});

app.get('/api/product/:slug', async (req, res) => {
    const { lang } = req.query;
    const slug = req.params.slug;
    
    // 1. Get Product
    const pRes = await pool.query(`SELECT * FROM products WHERE slug_i18n->>'en' = $1 OR slug_i18n->>'de' = $1 OR slug_i18n->>'fr' = $1`, [slug]);
    if (pRes.rows.length === 0) return res.status(404).json({ error: 'Not found' });
    const product = pRes.rows[0];

    // 2. Get SKUs
    const sRes = await pool.query(`SELECT * FROM skus WHERE product_id = $1`, [product.id]);
    
    // 3. Get Media
    const mRes = await pool.query(`SELECT * FROM media_assets WHERE bind_to_id = $1`, [product.id]);
    
    // 4. Get Docs
    const dRes = await pool.query(`SELECT * FROM documents WHERE applicable_to_id = $1`, [product.id]);

    res.json({ product, skus: sRes.rows, media: mRes.rows, docs: dRes.rows });
});

// --- API: Analytics ---
app.post('/api/event', async (req, res) => {
    const { event_type, payload } = req.body;
    await pool.query('INSERT INTO event_logs (event_type, payload) VALUES ($1, $2)', [event_type, payload]);
    res.status(201).send('Logged');
});

// --- API: Export Center (Admin) ---
app.get('/api/admin/export/:channel', async (req, res) => {
    const { channel } = req.params;
    
    // 1. Get Profile
    const profileRes = await pool.query('SELECT * FROM export_profiles WHERE channel = $1', [channel]);
    if (profileRes.rows.length === 0) return res.status(404).send('Profile not found');
    const profile = profileRes.rows[0];

    // 2. Get Data
    const products = await getFullProductDataForExport();

    // 3. Generate File
    const mapping = profile.mapping; // e.g., { "product_name": "model_name", "category": "etim_code" }
    
    if (profile.template_type === 'csv') {
        const headers = Object.keys(mapping);
        const csvRows = [headers.join(',')];
        
        products.forEach(p => {
            const row = headers.map(h => {
                const dbField = mapping[h]; // "model_name"
                // Simple mapping logic: map "title" -> p.model_name
                let val = '';
                if(dbField === 'title') val = p.model_name;
                else if(dbField === 'summary') val = p.summary?.en || '';
                else if(dbField === 'category_etim') val = p.etim_code || '';
                else if(dbField === 'main_image') val = p.main_image || '';
                
                // Validate required
                if (profile.required_rules.includes(h) && !val) {
                    console.warn(`Missing required field ${h} for product ${p.id}`);
                }
                return `"${String(val).replace(/"/g, '""')}"`;
            });
            csvRows.push(row.join(','));
        });

        res.header('Content-Type', 'text/csv');
        res.attachment(`${channel}_export_${Date.now()}.csv`);
        return res.send(csvRows.join('\n'));
    } 
    
    // Placeholder for Excel (using exceljs would go here)
    res.status(501).send('Excel not implemented in this demo block');
});

// --- Upload Handling ---
const upload = multer({ dest: path.join(__dirname, '../public/uploads') });
app.post('/api/admin/upload', upload.single('file'), (req, res) => {
    if(!req.file) return res.status(400).send('No file');
    // Rename to include extension
    const ext = path.extname(req.file.originalname);
    const newPath = req.file.path + ext;
    fs.renameSync(req.file.path, newPath);
    
    const fileUrl = `/uploads/${req.file.filename}${ext}`;
    res.json({ url: fileUrl, size: req.file.size });
});

app.listen(port, () => {
    console.log(`API running on http://localhost:${port}`);
});
