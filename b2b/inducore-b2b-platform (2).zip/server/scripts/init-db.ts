import { Client } from 'pg';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const client = new Client({
  connectionString: process.env.DATABASE_URL
});

async function run() {
  await client.connect();
  try {
    const schemaSql = fs.readFileSync(path.join(__dirname, '../../db/schema.sql'), 'utf8');
    const seedSql = fs.readFileSync(path.join(__dirname, '../../db/seed.sql'), 'utf8');
    
    console.log('Running Schema...');
    await client.query(schemaSql);
    console.log('Running Seeds...');
    await client.query(seedSql);
    console.log('Database Initialized Successfully.');
  } catch (e) {
    console.error(e);
  } finally {
    await client.end();
  }
}

run();