-- Categories
INSERT INTO categories (id, parent_id, level, name_i18n, slug_i18n, etim_code) VALUES 
(1, NULL, 1, '{"en": "Industrial Hydraulics", "de": "Industriehydraulik", "fr": "Hydraulique industrielle"}', '{"en": "hydraulics", "de": "hydraulik", "fr": "hydraulique"}', 'EC0001'),
(2, 1, 2, '{"en": "High Pressure Pumps", "de": "Hochdruckpumpen", "fr": "Pompes haute pression"}', '{"en": "pumps", "de": "pumpen", "fr": "pompes"}', 'EC0002');

-- Products
INSERT INTO products (brand, model_name, summary, description, primary_category_id, slug_i18n, industries) VALUES
('HydraForce', 'X-2000 Pro', 
 '{"en": "Heavy duty hydraulic pump for mining applications.", "de": "Schwerlast-Hydraulikpumpe für Bergbauanwendungen.", "fr": "Pompe hydraulique robuste pour applications minières."}',
 '{"en": "The X-2000 Pro features ultra-low vibration and high efficiency.", "de": "Die X-2000 Pro zeichnet sich durch extrem geringe Vibrationen aus.", "fr": "La X-2000 Pro présente des vibrations ultra-faibles."}',
 2,
 '{"en": "x-2000-pro-pump", "de": "x-2000-pro-pumpe", "fr": "pompe-x-2000-pro"}',
 ARRAY['Mining', 'Construction']
),
('HydraForce', 'EcoFlow S1', 
 '{"en": "Compact standard pump.", "de": "Kompakte Standardpumpe.", "fr": "Pompe standard compacte."}',
 '{"en": "Ideal for small automation cells.", "de": "Ideal für kleine Automatisierungszellen.", "fr": "Idéal pour les petites cellules d''automatisation."}',
 2,
 '{"en": "ecoflow-s1", "de": "ecoflow-s1", "fr": "ecoflow-s1"}',
 ARRAY['Automation']
);

-- SKUs
INSERT INTO skus (product_id, part_number, variant_attributes) VALUES
(1, 'HF-X2000-A1', '{"voltage": "240V", "mount": "Flange"}'),
(1, 'HF-X2000-A2', '{"voltage": "400V", "mount": "Foot"}');

-- Documents
INSERT INTO documents (doc_type, title_i18n, language, file_url, applicable_to_id, file_size) VALUES
('datasheet', '{"en": "Technical Data Sheet X2000", "de": "Technisches Datenblatt X2000"}', 'en', '/uploads/demo-datasheet.pdf', 1, 102400),
('manual', '{"en": "User Manual", "de": "Benutzerhandbuch"}', 'de', '/uploads/demo-manual-de.pdf', 1, 204800);

-- Media
INSERT INTO media_assets (type, file_url, bind_to_type, bind_to_id) VALUES
('image', 'https://picsum.photos/800/600', 'product', 1),
('3d', 'https://modelviewer.dev/shared-assets/models/Astronaut.glb', 'product', 1);

-- Export Profile (Europages)
INSERT INTO export_profiles (channel, template_type, mapping, required_rules) VALUES
('Europages', 'csv', 
 '{"product_name": "title", "description_short": "summary", "category_code": "category_etim", "img_url": "main_image"}',
 '["product_name", "category_code"]'
);
