-- Enable JSONB support
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Categories (Taxonomy)
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    parent_id INTEGER REFERENCES categories(id),
    level INTEGER NOT NULL,
    name_i18n JSONB NOT NULL,
    slug_i18n JSONB NOT NULL,
    etim_code VARCHAR(20),
    eclass_code VARCHAR(20),
    unspsc_code VARCHAR(20)
);

-- 2. Products (SPU)
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    brand VARCHAR(100) NOT NULL,
    family VARCHAR(100),
    model_name VARCHAR(100) NOT NULL,
    short_title VARCHAR(200),
    summary JSONB NOT NULL, -- {en: "...", de: "..."}
    description JSONB NOT NULL,
    industries TEXT[],
    applications TEXT[],
    primary_category_id INTEGER REFERENCES categories(id),
    slug_i18n JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- 3. SKUs (Variants)
CREATE TABLE skus (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    part_number VARCHAR(100) UNIQUE NOT NULL,
    variant_attributes JSONB, -- { "voltage": "24V", "power": "100W" }
    lead_time VARCHAR(50),
    status VARCHAR(20) DEFAULT 'active'
);

-- 4. Media Assets
CREATE TABLE media_assets (
    id SERIAL PRIMARY KEY,
    type VARCHAR(20) NOT NULL, -- image, video, 3d, cad
    file_url TEXT NOT NULL,
    thumb_url TEXT,
    title_i18n JSONB,
    bind_to_type VARCHAR(20), -- product, sku
    bind_to_id INTEGER,
    sort_order INTEGER DEFAULT 0
);

-- 5. Documents
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    doc_type VARCHAR(50) NOT NULL, -- datasheet, manual, certificate
    title_i18n JSONB NOT NULL,
    language VARCHAR(5),
    version VARCHAR(20),
    publish_date DATE,
    file_url TEXT NOT NULL,
    file_size INTEGER, -- in bytes
    access_level VARCHAR(20) DEFAULT 'public',
    applicable_to_type VARCHAR(20) DEFAULT 'product',
    applicable_to_id INTEGER
);

-- 6. Parameter Definitions (Dictionary)
CREATE TABLE parameter_definitions (
    id SERIAL PRIMARY KEY,
    name_i18n JSONB NOT NULL,
    unit VARCHAR(20),
    datatype VARCHAR(20) NOT NULL,
    platform_mapping_keys JSONB -- { "europages": "technique_1", "wlw": "attrib_x" }
);

-- 7. Parameter Values
CREATE TABLE parameter_values (
    id SERIAL PRIMARY KEY,
    owner_type VARCHAR(20) NOT NULL, -- product or sku
    owner_id INTEGER NOT NULL,
    param_id INTEGER REFERENCES parameter_definitions(id),
    value_numeric NUMERIC,
    value_text TEXT,
    value_enum VARCHAR(100)
);

-- 8. Export Profiles
CREATE TABLE export_profiles (
    id SERIAL PRIMARY KEY,
    channel VARCHAR(50) NOT NULL,
    template_type VARCHAR(10) NOT NULL, -- csv, xlsx
    mapping JSONB NOT NULL, -- internal_field -> external_header
    required_rules JSONB -- fields that must not be null
);

-- 9. Event Logs
CREATE TABLE event_logs (
    id SERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    payload JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);
