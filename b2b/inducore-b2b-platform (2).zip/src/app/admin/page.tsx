'use client';
import React, { useState } from 'react';

export default function AdminPage() {
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

  const handleExport = (channel: string) => {
    window.open(`${API_URL}/api/admin/export/${channel}`, '_blank');
  };

  return (
    <div className="container mx-auto p-10">
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>
      
      <div className="bg-white p-6 rounded shadow border mb-8">
        <h2 className="text-xl font-bold mb-4">Marketplace Exports</h2>
        <p className="mb-4 text-gray-600">Generate CSV/Excel feeds for external B2B platforms.</p>
        
        <div className="flex gap-4">
          <button 
            onClick={() => handleExport('Europages')}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Export to Europages (CSV)
          </button>
          
          <button 
            disabled
            className="bg-gray-300 text-gray-500 px-4 py-2 rounded cursor-not-allowed"
          >
            Export to WLW (Coming Soon)
          </button>
        </div>
      </div>

      <div className="bg-white p-6 rounded shadow border">
        <h2 className="text-xl font-bold mb-4">Content Management</h2>
        <p className="text-gray-500">
          Use the SQL Seed file to manage content in this demo version. 
          Full CRUD UI would connect to the endpoints defined in <code>server/index.ts</code>.
        </p>
      </div>
    </div>
  );
}