import React from 'react';
import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'InduCore Industrial Solutions',
  description: 'High-performance hydraulic systems and pumps.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/3.4.0/model-viewer.min.js"></script>
      </head>
      <body className={inter.className}>
        <nav className="bg-slate-900 text-white p-4 sticky top-0 z-50 shadow-md">
          <div className="container mx-auto flex justify-between items-center">
            <a href="/en/products" className="text-xl font-bold tracking-tight text-orange-500">INDUCORE</a>
            <div className="space-x-4 text-sm">
              <a href="/en/products" className="hover:text-orange-400">Products</a>
              <a href="/en/docs" className="hover:text-orange-400">Downloads</a>
              <span className="text-gray-500">|</span>
              <a href="/en/products" className="hover:text-white">EN</a>
              <a href="/de/products" className="hover:text-white">DE</a>
              <a href="/fr/products" className="hover:text-white">FR</a>
            </div>
          </div>
        </nav>
        <main className="min-h-screen bg-gray-50">
          {children}
        </main>
        <footer className="bg-gray-800 text-gray-400 p-8 text-center text-sm">
          <p>© 2024 InduCore Manufacturing. All rights reserved.</p>
        </footer>
      </body>
    </html>
  );
}