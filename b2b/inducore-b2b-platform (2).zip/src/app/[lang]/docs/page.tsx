import React from 'react';
import { fetchDocuments } from '@/lib/api';
import DownloadList from '@/components/DownloadList';

export default async function DocsPage({ params }: { params: { lang: string } }) {
  const docs = await fetchDocuments(params.lang);

  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-slate-800 mb-8">
        {params.lang === 'de' ? 'Dokumente & Downloads' : 
         params.lang === 'fr' ? 'Documents et Téléchargements' : 
         'Documents & Downloads'}
      </h1>
      <div className="bg-white p-8 rounded-lg shadow-sm border">
        {/* passing productId 0 for general downloads */}
        <DownloadList docs={docs} lang={params.lang} productId={0} /> 
      </div>
    </div>
  );
}
