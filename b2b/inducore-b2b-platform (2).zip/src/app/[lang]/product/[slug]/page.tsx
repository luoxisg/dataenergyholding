import React from 'react';
import { fetchProductDetail, logEvent } from '@/lib/api';
import { notFound } from 'next/navigation';
import { Product, SKU, Document, MediaAsset } from '@/types';
import DownloadList from '@/components/DownloadList';
import RFQForm from '@/components/RFQForm';

// Augment the global JSX namespace
declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': any;
    }
  }
}

export async function generateMetadata({ params }: any) {
  const data = await fetchProductDetail(params.slug, params.lang);
  if (!data) return {};
  const { product } = data;
  const title = (product.short_title || product.model_name) + ' | InduCore';
  
  // Hreflang generation logic would go here
  
  return {
    title,
    description: product.summary[params.lang] || product.summary['en'],
  };
}

export default async function ProductPage({ params }: { params: { lang: string, slug: string } }) {
  const data = await fetchProductDetail(params.slug, params.lang);
  if (!data) notFound();

  const { product, skus, media, docs } = data;
  const lang = params.lang as 'en' | 'de' | 'fr';

  // Find 3D model if exists
  const model3d = media.find((m: MediaAsset) => m.type === '3d');
  const mainImage = media.find((m: MediaAsset) => m.type === 'image');

  // JSON-LD Structured Data
  const jsonLd = {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": product.model_name,
    "description": product.description[lang] || product.description['en'],
    "brand": { "@type": "Brand", "name": product.brand },
    "sku": skus[0]?.part_number,
    "image": mainImage?.file_url
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-12">
        {/* Left: Visuals */}
        <div>
          {model3d ? (
            <div className="mb-4">
              <h3 className="text-sm font-semibold text-gray-500 mb-2 uppercase tracking-wide">3D Preview</h3>
              <model-viewer
                src={model3d.file_url}
                alt={product.model_name}
                auto-rotate
                camera-controls
                ar
                shadow-intensity="1"
              ></model-viewer>
            </div>
          ) : (
             <img src={mainImage?.file_url} className="w-full rounded-lg shadow" />
          )}
        </div>

        {/* Right: Info */}
        <div>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">{product.model_name}</h1>
          <p className="text-xl text-gray-600 mb-6">{product.summary[lang] || product.summary['en']}</p>
          
          <div className="bg-white p-6 rounded-lg border shadow-sm mb-6">
            <h3 className="font-bold text-lg mb-4">Specifications</h3>
            <table className="w-full text-sm">
              <tbody>
                {skus.map((sku: SKU) => (
                   <tr key={sku.id} className="border-b last:border-0">
                     <td className="py-2 font-mono text-orange-600">{sku.part_number}</td>
                     <td className="py-2 text-gray-600">
                        {Object.entries(sku.variant_attributes).map(([k, v]) => `${k}: ${v}`).join(', ')}
                     </td>
                   </tr>
                ))}
              </tbody>
            </table>
          </div>

          <RFQForm productId={product.id} />
        </div>
      </div>

      {/* Technical Docs Section */}
      <div className="bg-white rounded-lg shadow-sm border p-8 mb-12">
        <h2 className="text-2xl font-bold mb-6">Downloads & Documentation</h2>
        <DownloadList docs={docs} lang={lang} productId={product.id} />
      </div>

       {/* Detailed Description */}
       <div className="prose max-w-none text-slate-700">
          <h2 className="text-2xl font-bold mb-4">Product Description</h2>
          <p>{product.description[lang] || product.description['en']}</p>
       </div>
    </div>
  );
}