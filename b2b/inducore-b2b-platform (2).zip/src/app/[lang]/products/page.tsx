import React from 'react';
import { fetchProducts } from '@/lib/api';
import Link from 'next/link';
import { Product } from '@/types';

export default async function ProductsPage({ params }: { params: { lang: string } }) {
  const products = await fetchProducts(params.lang);

  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-slate-800 mb-8">
        {params.lang === 'de' ? 'Unsere Produkte' : 'Our Products'}
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((p: any) => (
          <Link href={`/${params.lang}/product/${p.slug}`} key={p.id} className="group">
            <div className="bg-white rounded-lg shadow-sm border hover:shadow-md transition overflow-hidden">
              <div className="h-48 bg-gray-200 relative">
                {p.thumb ? (
                  <img src={p.thumb} alt={p.model_name} className="w-full h-full object-cover" />
                ) : (
                   <div className="flex items-center justify-center h-full text-gray-400">No Image</div>
                )}
              </div>
              <div className="p-4">
                <h2 className="text-xl font-semibold text-slate-900 group-hover:text-orange-600">{p.model_name}</h2>
                <p className="text-gray-600 mt-2 text-sm line-clamp-2">{p.summary}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}