import { redirect } from 'next/navigation';

export default function LangPage({ params }: { params: { lang: string } }) {
  redirect(`/${params.lang}/products`);
}
