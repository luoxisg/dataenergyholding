import { Product, Document, SKU, MediaAsset } from '@/types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

// --- Mock Data for Fallback ---
const MOCK_PRODUCTS: any[] = [
  {
    id: 1,
    model_name: "X-2000 Pro (Offline Preview)",
    slug: "x-2000-pro-pump",
    summary: "Backend is unreachable. This is a mock product for preview purposes.",
    thumb: "https://picsum.photos/seed/1/400/300"
  },
  {
    id: 2,
    model_name: "EcoFlow S1 (Offline Preview)",
    slug: "ecoflow-s1",
    summary: "Backend is unreachable. This is a mock product for preview purposes.",
    thumb: "https://picsum.photos/seed/2/400/300"
  }
];

const MOCK_DOCS: Document[] = [
  {
    id: 1,
    doc_type: 'datasheet',
    title_i18n: { en: 'Offline Datasheet Preview', de: 'Offline Datenblatt', fr: 'Fiche technique hors ligne' },
    language: 'en',
    version: '1.0',
    publish_date: '2024-01-01',
    file_url: '#',
    file_size: 102400,
    applicable_to_id: 1
  }
];

// --- API Functions ---

export async function fetchProducts(lang: string) {
  try {
    const res = await fetch(`${API_URL}/api/products?lang=${lang}`, { cache: 'no-store' });
    if (!res.ok) throw new Error('Failed to fetch products');
    return await res.json();
  } catch (e) {
    console.warn('API unavailable, using mock data for products');
    return MOCK_PRODUCTS;
  }
}

export async function fetchProductDetail(slug: string, lang: string) {
  try {
    const res = await fetch(`${API_URL}/api/product/${slug}?lang=${lang}`, { cache: 'no-store' });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error('Failed to fetch detail');
    return await res.json();
  } catch (e) {
    console.warn('API unavailable, using mock data for detail');
    // Return a mock product detail structure matching the expected API response
    return {
        product: {
            id: 1,
            brand: "MockBrand",
            family: "Hydraulics",
            model_name: "X-2000 Pro (Offline)",
            short_title: "X-2000 Pro",
            summary: { en: "Backend unreachable. Mock Data.", de: "Backend nicht erreichbar.", fr: "Backend inaccessible." },
            description: { en: "This content is shown because the API server is offline.", de: "Dieser Inhalt wird angezeigt, weil der API-Server offline ist.", fr: "Ce contenu est affiché car le serveur API est hors ligne." },
            industries: ["Demo"],
            applications: ["Preview"],
            primary_category_id: 1,
            slug_i18n: { en: "x-2000-pro-pump", de: "x-2000-pro-pump", fr: "x-2000-pro-pump" }
        } as Product,
        skus: [{ id: 1, product_id: 1, part_number: "MOCK-SKU-001", lead_time: "2 weeks", variant_attributes: { voltage: "24V", power: "100W" } }] as SKU[],
        media: [{ id: 1, type: "image", file_url: "https://picsum.photos/seed/1/800/600", bind_to_id: 1 }] as MediaAsset[],
        docs: MOCK_DOCS
    };
  }
}

export async function fetchDocuments(lang: string) {
    try {
        const res = await fetch(`${API_URL}/api/documents?lang=${lang}`, { cache: 'no-store' });
        if (!res.ok) throw new Error('Failed to fetch docs');
        return await res.json();
    } catch (e) {
        console.warn('API unavailable, using mock data for docs');
        return MOCK_DOCS;
    }
}

export async function logEvent(type: string, payload: any) {
  try {
    await fetch(`${API_URL}/api/event`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event_type: type, payload }),
    });
  } catch (e) {
    console.warn('Analytics failed (Backend unreachable)');
  }
}
