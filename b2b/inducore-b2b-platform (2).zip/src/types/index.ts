export type Lang = 'en' | 'de' | 'fr';

export interface LocalizedString {
  [key: string]: string; // en, de, fr
}

export interface Product {
  id: number;
  brand: string;
  family: string;
  model_name: string;
  short_title: string;
  summary: LocalizedString;
  description: LocalizedString;
  industries: string[];
  applications: string[];
  primary_category_id: number;
  slug_i18n: LocalizedString;
}

export interface SKU {
  id: number;
  product_id: number;
  part_number: string;
  lead_time: string;
  variant_attributes: Record<string, any>;
}

export interface Document {
  id: number;
  doc_type: 'whitepaper' | 'datasheet' | 'certificate' | 'manual';
  title_i18n: LocalizedString;
  language: string;
  version: string;
  publish_date: string;
  file_url: string;
  file_size: number;
  applicable_to_id: number;
}

export interface MediaAsset {
  id: number;
  type: 'image' | 'video' | '3d' | 'cad';
  file_url: string;
  thumb_url?: string;
  title_i18n?: LocalizedString;
  bind_to_id: number;
}

export interface Category {
  id: number;
  name_i18n: LocalizedString;
  slug_i18n: LocalizedString;
  level: number;
  parent_id: number | null;
}
