'use client';
import React from 'react';
import { Document } from '@/types';
import { logEvent } from '@/lib/api';
import { FileText, Download } from 'lucide-react';

export default function DownloadList({ docs, lang, productId }: { docs: Document[], lang: string, productId: number }) {
  
  const handleDownload = (docId: number) => {
    logEvent('doc_download', { product_id: productId, doc_id: docId, language: lang, time: new Date() });
  };

  if (docs.length === 0) return <p className="text-gray-500 italic">No documents available.</p>;

  // Group by type
  const grouped = docs.reduce((acc, doc) => {
    acc[doc.doc_type] = [...(acc[doc.doc_type] || []), doc];
    return acc;
  }, {} as Record<string, Document[]>);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {Object.entries(grouped).map(([type, typeDocs]: [string, Document[]]) => (
        <div key={type} className="border rounded p-4">
          <h3 className="font-bold uppercase text-gray-500 text-xs mb-3">{type}</h3>
          <ul className="space-y-2">
            {typeDocs.map(doc => {
              const title = (doc.title_i18n as any)[lang] || (doc.title_i18n as any)['en'];
              return (
                <li key={doc.id} className="flex items-center justify-between group">
                  <div className="flex items-center">
                    <FileText className="w-4 h-4 text-blue-500 mr-2" />
                    <div>
                      <span className="text-sm font-medium text-gray-800">{title}</span>
                      <span className="text-xs text-gray-400 block">{(doc.file_size / 1024).toFixed(0)} KB • {doc.version}</span>
                    </div>
                  </div>
                  <a 
                    href={doc.file_url} 
                    target="_blank"
                    onClick={() => handleDownload(doc.id)}
                    className="p-2 text-gray-400 hover:text-orange-500 transition"
                  >
                    <Download className="w-5 h-5" />
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </div>
  );
}