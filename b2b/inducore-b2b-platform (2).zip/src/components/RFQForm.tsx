'use client';
import React, { useState } from 'react';
import { logEvent } from '@/lib/api';

export default function RFQForm({ productId }: { productId: number }) {
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In real app: validate and send to API
    logEvent('rfq_submit', { product_id: productId });
    setSent(true);
  };

  if (sent) return <div className="p-4 bg-green-50 text-green-700 border border-green-200 rounded">Request sent successfully! Our sales team will contact you.</div>;

  return (
    <form onSubmit={handleSubmit} className="bg-orange-50 p-6 rounded-lg border border-orange-100">
      <h3 className="font-bold text-lg mb-4 text-orange-800">Request Quote</h3>
      <div className="space-y-3">
        <input type="email" required placeholder="Business Email" className="w-full p-2 border rounded" />
        <input type="text" placeholder="Company Name" className="w-full p-2 border rounded" />
        <textarea placeholder="Message / Quantity" className="w-full p-2 border rounded h-20"></textarea>
        <button type="submit" className="w-full bg-orange-600 text-white font-bold py-2 rounded hover:bg-orange-700 transition">
          Send Inquiry
        </button>
      </div>
    </form>
  );
}